<?php
$pizzas = array(
    'Margherita' => 5.45,
    'Pepperoni' => 6.85,
    'BBQ Chicken' => 7.99,
    'Veggie' => 3.49
)
?>