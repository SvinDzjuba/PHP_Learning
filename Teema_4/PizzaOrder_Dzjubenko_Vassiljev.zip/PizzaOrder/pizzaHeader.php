    <div class="container">
    <h2>Choose your pizza</h2>
        <div class="content">
            <article>
                <p>
                    <strong>Our address: </strong>64, Nnamdi Azikwe Street, Lagos Island, Nigeria<br>
                    <strong>Phone: </strong>+234-80-24124387
                </p>
