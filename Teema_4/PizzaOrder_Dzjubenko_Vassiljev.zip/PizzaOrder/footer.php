</article>
</div>
    <footer>
        <hr>
        <p>&copy; Dzjubenko & Vassiljev</p>
    </footer>
</div>
</body>
</html>